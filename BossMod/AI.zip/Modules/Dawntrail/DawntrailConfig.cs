﻿namespace BossMod.Dawntrail;

[ConfigDisplay(Order = 5, Parent = typeof(ModuleConfig))]
public sealed class DawntrailConfig() : ConfigNode();
